<?php include 'header.php'; ?>
<section class="service-main uadoc bg-gradian">
    <div class="container container-padding">
        <div class="row">
            <div class="col-xl-1 col-lg-1 lap-d-none"></div>
            <div class="col-xl-2 col-lg-2 col-md-3 col-sm-4 col-12 text-center">
                <a href=""><img src="./assets/images/uadoc/1.png" alt=""></a>
                <h5>Livre electronique</h5>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-3 col-sm-4 col-12 text-center">
                <a href=""><img src="./assets/images/uadoc/2.png" alt=""></a>
                <h5>Livre electronique</h5>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-3 col-sm-4 col-12 text-center">
                <a href=""><img src="./assets/images/uadoc/3.png" alt=""></a>
                <h5>Livre electronique</h5>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-3 col-sm-4 col-12 text-center">
                <a href=""><img src="./assets/images/uadoc/4.png" alt=""></a>
                <h5>Livre electronique</h5>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-3 col-sm-4 col-12 text-center">
                <a href=""><img src="./assets/images/uadoc/5.png" alt=""></a>
                <h5>Livre electronique</h5>
            </div>
            <div class="col-xl-1 col-lg-1 lap-d-none"></div>
            <div class="col-xl-1 col-lg-1 lap-d-none"></div>
            <div class="col-xl-2 col-lg-2 col-md-3 col-sm-4 col-12 text-center">
                <a href=""><img src="./assets/images/uadoc/1.png" alt=""></a>
                <h5>Livre electronique</h5>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-3 col-sm-4 col-12 text-center">
                <a href=""><img src="./assets/images/uadoc/2.png" alt=""></a>
                <h5>Livre electronique</h5>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-3 col-sm-4 col-12 text-center">
                <a href=""><img src="./assets/images/uadoc/3.png" alt=""></a>
                <h5>Livre electronique</h5>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-3 col-sm-4 col-12 text-center">
                <a href=""><img src="./assets/images/uadoc/4.png" alt=""></a>
                <h5>Livre electronique</h5>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-3 col-sm-4 col-12 text-center">
                <a href=""><img src="./assets/images/uadoc/5.png" alt=""></a>
                <h5>Livre electronique</h5>
            </div>
            <div class="col-xl-1 col-lg-1 lap-d-none"></div>
        </div>
    </div>
</section>
<?php include 'footer.php'; ?>